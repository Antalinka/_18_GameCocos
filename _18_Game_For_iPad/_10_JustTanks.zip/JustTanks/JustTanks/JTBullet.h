//
//  JTBullet.h
//  JustTanks
//
//  Created by Exo-terminal on 4/2/14.
//  Copyright 2014 Evgenia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "JTObject.h"


@interface JTBullet : JTObject {
    
}
@property (assign, nonatomic) float distance;
@end
