//
//  JTEnemyTank.h
//  JustTanks
//
//  Created by Exo-terminal on 4/4/14.
//  Copyright 2014 Evgenia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "JTObject.h"

@interface JTEnemyTank : JTObject {
    
}

@end
