//
//  JTBullet.m
//  JustTanks
//
//  Created by Exo-terminal on 4/2/14.
//  Copyright 2014 Evgenia. All rights reserved.
//

#import "JTBullet.h"


@implementation JTBullet
-(id)initWithSprite:(CCSprite *)sprt scene:(JTGameScene *)scene properties:(NSDictionary *)props{
    if (self = [super initWithSprite:sprt scene:scene properties:props ]) {
        _distance = 500;
        
        self.rotation = [[props objectForKey:@"rotation"] floatValue];
        self.position = [[props objectForKey:@"position"]CGPointValue];
        
        float rad = self.rotation * (M_PI / 180);
        
        CGPoint aimPos = ccpAdd(self.position, ccp(sin(rad) * _distance, cos(rad) * _distance));
        
        id mov = [CCMoveTo actionWithDuration:0.5f position:aimPos];
        id cal =[CCCallBlock actionWithBlock:^{
            [self removeFromParentAndCleanup:YES];
        }];
        [self runAction:[CCSequence actions:mov,cal,nil]];
    }
    return self;
}
-(void)update:(float)dt{
    
}
@end
