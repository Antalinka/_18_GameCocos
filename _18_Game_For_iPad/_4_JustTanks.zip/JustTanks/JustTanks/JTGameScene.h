//
//  JTGameScene.h
//  JustTanks
//
//  Created by Exo-terminal on 3/31/14.
//  Copyright 2014 Evgenia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface JTGameScene : CCLayer {
    
}
+(CCScene *) scene;

@property (assign, nonatomic) BOOL isMovingForward;
@property (assign, nonatomic) BOOL isMovingBack;
@property (assign, nonatomic) BOOL isRotatingLeft;
@property (assign, nonatomic) BOOL isRotatingRight;

@end
