//
//  JTPlayerTank.m
//  JustTanks
//
//  Created by Exo-terminal on 4/1/14.
//  Copyright 2014 Evgenia. All rights reserved.
//

#import "JTPlayerTank.h"
#import "JTGameScene.h"
#import "JTBullet.h"

#define bullet_tag 1235
#define trace_duration 10
#define trace_delay 6
#define offset_y 35

@interface JTPlayerTank ()
@property (assign, nonatomic) float speed;
@property (assign, nonatomic) int traceCounter;

@end


@implementation JTPlayerTank
-(id) initWithSprite:(CCSprite *)sprt scene:(JTGameScene *)scene properties:(NSDictionary *)props{
    if (self = [super initWithSprite:sprt scene:scene properties:props]) {
        
        _speed = 160;
        
    }
    return self;
}

-(void)update:(float)dt{
    
    float rad = self.rotation * (M_PI / 180);
    CGPoint pretendPoint = CGPointZero;
    
    if (self.scene.isMovingForward) pretendPoint = ccpAdd(self.position, ccp(sin(rad) * dt * _speed,cos(rad) * dt * _speed   ));
    else if(self.scene.isMovingBack) pretendPoint = ccpAdd(self.position, ccp(-sin(rad) * dt * _speed,-cos(rad) * dt * _speed   ));

    
    if (pretendPoint.x - self.sprite.contentSize.width/2 > 0 && pretendPoint.x + self.sprite.contentSize.width/2 < self.winSize.width &&
        pretendPoint.y - self.sprite.contentSize.height/2 > 0 && pretendPoint.y + self.sprite.contentSize.height/2 < self.winSize.height) {
        self.position = pretendPoint;
        
        float offseY = 0;
        if (self.scene.isMovingForward) offseY = -offset_y;
        else if (self.scene.isMovingBack) offseY = offset_y;
        
        _traceCounter++;
        
        if (_traceCounter > trace_delay) {
            
            _traceCounter = 0;
            
            CCSprite* traces = [CCSprite spriteWithFile:@"traces.png"];
            traces.position = [self convertToWorldSpace:ccp(0, offseY)];
            traces.rotation = self.rotation;
            [self.scene addChild:traces];
            
            id fade = [CCFadeOut actionWithDuration:trace_duration];
            id cal = [CCCallBlock actionWithBlock:^{
                [traces removeFromParentAndCleanup:YES];
            }];
            [traces runAction:[CCSequence actions:fade, cal, nil]];
            }
    }
    
    
    if (self.scene.isRotatingLeft)self.rotation -= 1 * dt * (_speed/2);
    else if  (self.scene.isRotatingRight)self.rotation += 1 * dt * (_speed/2);


    
}

-(void) shoot{
    
    NSDictionary* dict = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithFloat:self.rotation],@"rotation",
                          [NSValue valueWithCGPoint:[self convertToWorldSpace:ccp(0, 55) ]] ,@"position", nil];
    
    JTBullet* bullet = [[JTBullet alloc]initWithSprite: [CCSprite spriteWithFile:@"shot.png"] scene:self.scene properties:dict];
    bullet.tag = bullet_tag;
    [self.scene addChild:bullet z:55];
}

@end

