//
//  JTGameScene.m
//  JustTanks
//
//  Created by Exo-terminal on 3/31/14.
//  Copyright 2014 Evgenia. All rights reserved.
//

#import "JTGameScene.h"
#import "JTObject.h"
#import "JTPlayerTank.h"

#define pressed_tag 1234

@interface JTGameScene()
@property (strong, nonatomic) JTPlayerTank* playerTank;
@property (unsafe_unretained, nonatomic) CGSize winSize;
@property (strong, nonatomic) CCSprite* rotLeft;
@property (strong, nonatomic) CCSprite* rotRight;
@property (strong, nonatomic) CCSprite* moveForward;
@property (strong, nonatomic) CCSprite* moveBack;
@property (strong, nonatomic) CCSprite* attack;
@end

@interface JTGameScene (private)

-(CCSprite*) buttonWithName:(NSString*) name pressedName: (NSString*) pressedName pos:(CGPoint) pos flipX:(BOOL) flipX flipY:(BOOL) flipY;

@end

@implementation JTGameScene

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	JTGameScene *layer = [JTGameScene node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

#pragma mark - INIT -

-(id)init{
    if (self == [super init]) {
        
        _wallsArray = [[NSMutableArray alloc]init];
        
        
        self.winSize = [CCDirector sharedDirector].winSize;
        
        CCLayerColor* lc = [CCLayerColor layerWithColor:ccc4(20, 35, 20, 255)];
        [self addChild:lc];
        
        NSDictionary* dict = [[NSDictionary alloc]initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Level_1" ofType:@"plist"]];
        NSArray* array = [dict objectForKey:@"Walls"];
        
        for (NSDictionary *wallDict in array) {
            CCSprite* wall = [CCSprite spriteWithFile:@"brickWall.png"];
            wall.position = ccp([[wallDict objectForKey:@"x"]floatValue], [[wallDict objectForKey:@"y"]floatValue]);
            [self addChild:wall];
            
            [_wallsArray addObject:wall];
        }
        
        
        _playerTank = [[JTPlayerTank alloc]initWithSprite:[CCSprite spriteWithFile:@"Tank1.png"] scene:self properties:nil];
        _playerTank.position = ccp(_winSize.width/2, _winSize.height/2);
        [self addChild:_playerTank z:50];
        
        _rotLeft = [self buttonWithName:@"btnRotate.png" pressedName:@"btnRotatePressed.png" pos:ccp(40, 100) flipX:YES flipY:NO];
        _rotRight = [self buttonWithName:@"btnRotate.png" pressedName:@"btnRotatePressed.png" pos:ccp(160, 100) flipX:NO flipY:NO];
        _moveForward = [self buttonWithName:@"btnArrow.png" pressedName:@"btnArrowPressed.png" pos:ccp(100, 150) flipX:NO flipY:NO];
        _moveBack = [self buttonWithName:@"btnArrow.png" pressedName:@"btnArrowPressed.png" pos:ccp(100, 40) flipX:NO flipY:YES];
        _attack = [self buttonWithName:@"btnFire.png" pressedName:@"btnFirePressed.png" pos:ccp(_winSize.width - 80, 100) flipX:NO flipY:NO];
        
        self.touchEnabled = YES;

        NSLog(@"init");
    }
    return self;
}

#pragma mark - PRIVAT METHODS -

-(CGRect) getRectFromSprite: (CCSprite*) sprt{
    return CGRectMake(sprt.position.x - sprt.contentSize.width/2, sprt.position.y - sprt.contentSize.height/2,
                      sprt.contentSize.width, sprt.contentSize.height);
}

-(CCSprite*) buttonWithName:(NSString*) name pressedName: (NSString*) pressedName pos:(CGPoint) pos flipX:(BOOL) flipX flipY:(BOOL) flipY{
    
    CCSprite* sprt = [CCSprite spriteWithFile:name];
    sprt.position = pos;
    sprt.flipX = flipX;
    sprt.flipY =flipY;
    [self addChild:sprt z:100];
    
    CCSprite* pressed = [CCSprite spriteWithFile:pressedName];
    pressed.flipX = flipX;
    pressed.flipY =flipY;
    pressed.anchorPoint = ccp(0, 0);
    pressed.tag = pressed_tag;
    pressed.visible = NO;
    [sprt addChild:pressed];
    
    return sprt;
}

-(void) checkForActionInBeggining:(CCSprite*) sprt isDoing:(BOOL*) isDoing location:(CGPoint) location{
    
    if (CGRectContainsPoint([self getRectFromSprite:sprt], location)) {
        
        CCNode *pressed = [sprt getChildByTag:pressed_tag];
        pressed.visible = YES;
        *isDoing = YES;
    }
    
}
-(void) checkForActionInEndning:(CCSprite*) sprt isDoing:(BOOL*) isDoing location:(CGPoint) location{
    
    if (CGRectContainsPoint([self getRectFromSprite:sprt], location)) {
        
        CCNode *pressed = [sprt getChildByTag:pressed_tag];
        pressed.visible = NO;
        *isDoing = NO;
    }
    
}


#pragma mark - TOUCHES -

-(void) ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    for( UITouch *touch in touches ) {
        
        CGPoint position = [[CCDirector sharedDirector] convertToGL:[touch locationInView:[touch view]]];
        
        [self checkForActionInBeggining:_rotLeft isDoing:&_isRotatingLeft location:position];
        [self checkForActionInBeggining:_rotRight isDoing:&_isRotatingRight location:position];
        [self checkForActionInBeggining:_moveForward isDoing:&_isMovingForward location:position];
        [self checkForActionInBeggining:_moveBack isDoing:&_isMovingBack location:position];
        
        if (CGRectContainsPoint([self getRectFromSprite:_attack], position)) {
            CCNode *pressed = [_attack getChildByTag:pressed_tag];
            pressed.visible = YES;
            
            [_playerTank shoot];
        }
    }
}

- (void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    
    for( UITouch *touch in touches ) {
        
        CGPoint position = [[CCDirector sharedDirector] convertToGL:[touch locationInView:[touch view]]];
    }

}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
   
    for( UITouch *touch in touches ) {
        
        CGPoint position = [[CCDirector sharedDirector] convertToGL:[touch locationInView:[touch view]]];

        [self checkForActionInEndning:_rotLeft isDoing:&_isRotatingLeft location:position];
        [self checkForActionInEndning:_rotRight isDoing:&_isRotatingRight location:position];
        [self checkForActionInEndning:_moveForward isDoing:&_isMovingForward location:position];
        [self checkForActionInEndning:_moveBack isDoing:&_isMovingBack location:position];
        
        if (CGRectContainsPoint([self getRectFromSprite:_attack], position)) {
            CCNode *pressed = [_attack getChildByTag:pressed_tag];
            pressed.visible = NO;
            
        }

    }
}

@end
