//
//  JTBullet.m
//  JustTanks
//
//  Created by Exo-terminal on 4/2/14.
//  Copyright 2014 Evgenia. All rights reserved.
//

#import "JTBullet.h"
#import "JTGameScene.h"
#import "SimpleAudioEngine.h"


@implementation JTBullet

-(void) animateExplosion{
    
   [[SimpleAudioEngine sharedEngine] playEffect:@"Explosion1.mp3"];
    NSMutableArray* animFrames = [NSMutableArray array];
    
    for (int i = 1; i < 16; i++) {
        CCSpriteFrame* frame = [[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:[NSString stringWithFormat:@"expl_%d.png", i]];
        [animFrames addObject:frame];
    }
    
    CCSprite* expl = [CCSprite spriteWithSpriteFrameName:@"expl_1.png"];
    expl.position = self.position;
    expl.scale = 2;
    [self.scene addChild:expl z:55];
    
    CCAnimation* animation = [CCAnimation animationWithSpriteFrames:animFrames delay:0.05f];
    
    id anim = [CCAnimate actionWithAnimation:animation];
    
    id call = [CCCallBlock actionWithBlock:^{
        [expl removeFromParentAndCleanup:YES];
    }];
    [expl runAction:[CCSequence actions:anim, call, nil]];
    
}
-(id)initWithSprite:(CCSprite *)sprt scene:(JTGameScene *)scene properties:(NSDictionary *)props{
    if (self = [super initWithSprite:sprt scene:scene properties:props ]) {
        
        [[SimpleAudioEngine sharedEngine] playEffect:@"shot.wav"];
        
        _distance = 500;
        
        self.rotation = [[props objectForKey:key_rotation] floatValue];
        self.position = [[props objectForKey:key_position]CGPointValue];
        
        float rad = self.rotation * (M_PI / 180);
        
        CGPoint aimPos = ccpAdd(self.position, ccp(sin(rad) * _distance, cos(rad) * _distance));
        
        id mov = [CCMoveTo actionWithDuration:0.5 position:aimPos];
        id cal =[CCCallBlock actionWithBlock:^{
            
            [self animateExplosion];
            [self removeFromParentAndCleanup:YES];

        }];
        [self runAction:[CCSequence actions:mov,cal,nil]];
    }
    return self;
}
-(void)update:(float)dt{
    
    NSMutableArray* deleteArray = [[NSMutableArray alloc]init];
    
    for (CCSprite *wall in self.scene.wallsArray) {
        if (CGRectContainsPoint([self.scene getRectFromSprite:wall], self.position)) {
            
            [deleteArray addObject:wall];
            [wall removeFromParentAndCleanup:YES];
            [self animateExplosion];
            [self removeFromParentAndCleanup:YES];
        }
    }
    
    for (CCSprite *wall in deleteArray) {
        [self.scene.wallsArray removeObject:wall];
    }
    [deleteArray removeAllObjects];
}
@end
